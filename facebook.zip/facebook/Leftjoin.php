<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Left join</title>
</head>
<body>
<table style='border: 5px solid lightgreen; border-collapse:collapse;'>
        <tr style='border: 1px solid; border-collapse:collapse;'>
            <th>id</th>
            <th>username</th>
            <th>email</th>
            <th> create_at</th>
            <th>user_id</th>
            <th>content</th>
            

        </tr>
        <?php
        $conn = mysqli_connect("localhost", "Richie", "Richie@7excel", "facebook");
        $query = 'select * from users left join post on users.id = post.user_id';
        $result = mysqli_query($conn, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            echo 
            "<tr>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[id]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[username]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[email]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[create_at]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[user_id]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[content]</td>
            
        
        </tr>";
        }

        ?>

    </table>
</body>
</html>