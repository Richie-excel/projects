<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inner join</title>
</head>

<body>
    <table style='border: 5px solid lightgreen; border-collapse:collapse;'>
        <tr>
            <th>id</th>
            <th>username</th>
            <th>user_id</th>
            <th>content</th>
            <th>post_id</th>
            
        </tr>
        <?php
        $conn = mysqli_connect("localhost", "Richie", "Richie@7excel", "facebook");
        $query = 'select * from users inner join post on users.id = post.user_id';
        $result = mysqli_query($conn, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            echo 
            "<tr style='border:3px solid cyan; border-collapse:collapse;'>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[id]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[username]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[user_id]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[content]</td>
            <td style='border: 3px solid cyan; border-collapse:collapse;'>$row[post_id]</td>
        
        </tr>";
        }

        ?>

    </table>
</body>

</html>